import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RefundComponent } from './refund/refund.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { GovtComponent } from './govt/govt.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    ProductpageComponent,
    AddproductComponent,
    TransactionComponent,
    RefundComponent,
    SignupComponent,
    LoginComponent,
    GovtComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

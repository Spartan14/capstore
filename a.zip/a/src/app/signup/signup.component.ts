import { Component, OnInit } from '@angular/core';
import { NgIf } from '../../../node_modules/@angular/common';
import {Router} from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private router: Router) { }
  ngOnInit() {
  }
  signup(add)
  {
   
   if(add.select=="customer"){
    
   }
   else if(add.select=="merchant"){
    this.router.navigate(['/govt'])

   }
   else{}
}
}

